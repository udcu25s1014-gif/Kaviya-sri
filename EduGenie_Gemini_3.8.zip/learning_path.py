"""
learning_path.py
Generates a structured, adaptive learning path for a given topic.
"""

from config import client, GEMINI_MODEL


def get_learning_recommendations(topic: str) -> str:
    prompt = f"""You are an AI tutor. The student wants to learn about: {topic}.
Suggest a structured and adaptive learning path including key topics, order
of learning, and useful resources (videos, articles, or books).
Include beginner, intermediate, and advanced levels if needed.
"""
    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
        )
        if getattr(response, "text", None):
            return response.text
        return "⚠️ Could not extract content from Gemini response."
    except Exception as e:
        return f"⚠️ Error occurred: {e}"
