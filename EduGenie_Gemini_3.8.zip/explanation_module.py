"""
explanation_module.py
Simplified concept explanations for learners of any level.

Note: the original project spec used a local LaMini-Flan-T5 model
(via `transformers` + `torch`) for this module. That works, but it
requires downloading a multi-GB model and a GPU/CPU-heavy inference
step the first time you run it. To keep this project easy to install
and reliable to run, this version uses the same Gemini API used by
the other modules instead. If you specifically want the local
LaMini-Flan-T5 model, see the commented alternative at the bottom
of this file.
"""

from config import client, GEMINI_MODEL


def explain_topic(topic: str) -> str:
    """Return a short, simple explanation of `topic` for a school student."""
    prompt = (
        f"Explain the concept of '{topic}' in a simple and clear way "
        f"for a school student. Keep it concise (3-6 sentences), avoid "
        f"jargon, and include a short everyday example if it helps."
    )
    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
        )
        return response.text.strip()
    except Exception as e:
        return f"⚠️ Error in Explanation: {e}"


# ---------------------------------------------------------------------------
# OPTIONAL: local LaMini-Flan-T5 version (matches the original project spec).
# Uncomment this block, comment out the function above, and run:
#   pip install transformers torch
# The first call will download the ~1.5GB model from Hugging Face.
# ---------------------------------------------------------------------------
#
# from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
#
# explain_tokenizer = AutoTokenizer.from_pretrained("MBZUAI/LaMini-Flan-T5-783M")
# explain_model = AutoModelForSeq2SeqLM.from_pretrained("MBZUAI/LaMini-Flan-T5-783M")
#
# def explain_topic(topic: str) -> str:
#     input_text = f"Explain the concept of '{topic}' in a simple and clear way for a school student."
#     inputs = explain_tokenizer(input_text, return_tensors="pt")
#     outputs = explain_model.generate(
#         **inputs,
#         max_new_tokens=150,
#         temperature=0.7,
#         top_k=50,
#         top_p=0.95,
#         do_sample=True,
#     )
#     return explain_tokenizer.decode(outputs[0], skip_special_tokens=True)
