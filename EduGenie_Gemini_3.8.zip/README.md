# EduGenie — Google Gemini Powered Learning Assistant

A FastAPI + Gemini web app with 5 features: Q&A, concept explanations,
summarization, quiz generation, and personalized learning paths.

## Project structure

```
EduGenie/
├── main.py                 # FastAPI app + all routes
├── config.py                # Loads .env, creates the Gemini client
├── qna.py                   # /qa module
├── explanation_module.py    # /explain module
├── quiz_module.py           # /quiz module
├── summary_module.py        # /summarize module
├── learning_path.py         # /learn/recommendations module
├── requirements.txt
├── .env.example
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
```

## 1. Get a Gemini API key

1. Go to https://aistudio.google.com/apikey
2. Sign in with a Google account and click "Create API key".
3. Copy the key — you'll paste it in step 4 below.

## 2. Open the project in VS Code

1. Unzip the project folder and open it in VS Code (`File > Open Folder`).
2. Open a terminal in VS Code: `Terminal > New Terminal`.

## 3. Create a virtual environment and install dependencies

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate

pip install -r requirements.txt
```

VS Code may prompt you to select the `venv` interpreter — choose it
(bottom-right corner, or `Ctrl+Shift+P` → "Python: Select Interpreter").

## 4. Add your API key

Copy `.env.example` to a new file named `.env` in the same folder, then
edit it:

```
GEMINI_API_KEY=paste_your_real_key_here
GEMINI_MODEL=gemini-3.8-flash
```

`.env` is never committed to source control — keep your key private.

## 5. Run the app

```bash
uvicorn main:app --reload
```

You should see something like:

```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Application startup complete.
```

Open **http://127.0.0.1:8000** in your browser.

## 6. Test it

On the page you can:
- **Ask a question** — e.g. "Which is the largest ocean?"
- **Get an explanation** — e.g. "Photosynthesis"
- **Summarize a paragraph** — paste any long text
- **Generate a quiz** — e.g. "Pythagoras theorem" → 3 MCQs, click an
  option then "Check Answer"
- **Get learning recommendations** — e.g. "SQL" → a full beginner-to-advanced path

You can also hit the API directly, e.g. in a browser or with `curl`:

```bash
curl "http://127.0.0.1:8000/qa?question=Why+is+the+sky+blue"
curl "http://127.0.0.1:8000/learn/recommendations?topic=SQL"
```

FastAPI also auto-generates interactive API docs at
**http://127.0.0.1:8000/docs**, where you can try every endpoint directly.

## Notes on design choices vs. the original spec

- The original spec used a local **LaMini-Flan-T5** model (via
  `transformers` + `torch`) for the Explanation module, and Gemini for
  everything else. That model download is several GB and adds fragile
  setup steps (torch install, first-run download, CPU inference time).
  To keep this project a single reliable dependency, `explanation_module.py`
  uses Gemini too, with a prompt tuned to give simple, student-friendly
  explanations. The original local-model code is included, commented out,
  at the bottom of `explanation_module.py` if you'd like to switch to it.
- Uses the current `google-genai` SDK (`google.genai`) and `gemini-3.8-flash`
  by default, since the older `google-generativeai` SDK / `gemini-1.5-pro`
  path referenced in the original spec is being phased out. You can change
  the model via `GEMINI_MODEL` in `.env` (e.g. to `gemini-3.8-flash` for
  higher-quality but slower/more expensive responses).

## Troubleshooting

| Problem | Fix |
|---|---|
| `RuntimeError: GEMINI_API_KEY is not set` | Make sure you created `.env` (not just `.env.example`) and restarted the server. |
| `ModuleNotFoundError` | Make sure your venv is activated and `pip install -r requirements.txt` finished without errors. |
| Quiz shows "Could not parse quiz JSON" | Rare model formatting hiccup — click "Generate Quiz" again. |
| Port 8000 already in use | Run `uvicorn main:app --reload --port 8001` instead, then visit that port. |
