"""
quiz_module.py
Generates 3 multiple-choice questions (4 options each) from a passage of
text, using Gemini, and returns them as a parsed Python list of dicts.
"""

import json
import re
from config import client, GEMINI_MODEL


def clean_json_block(text: str) -> str:
    """Strip ```json ... ``` markdown fences if the model adds them."""
    return re.sub(r"```(?:json)?\n?(.*?)```", r"\1", text, flags=re.DOTALL).strip()


def generate_quiz(text: str) -> list:
    """Return a list of {question, options, answer} dicts, or an error dict."""
    prompt = f"""You are a quiz generator.

From the following passage, create 3 multiple-choice questions. Each question
must include:
- "question": the question text
- "options": a list of exactly 4 answer choices
- "answer": the correct option, copied exactly as it appears in "options"

Respond with ONLY valid JSON in exactly this shape, and nothing else
(no markdown fences, no commentary):
[
  {{
    "question": "What is ...?",
    "options": ["A", "B", "C", "D"],
    "answer": "A"
  }}
]

Passage:
{text}
"""
    quiz_text = ""
    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
        )
        quiz_text = response.text.strip()
        cleaned_text = clean_json_block(quiz_text)
        quiz = json.loads(cleaned_text)
        return quiz
    except json.JSONDecodeError as e:
        return [{"error": f"Could not parse quiz JSON: {e}", "raw": quiz_text}]
    except Exception as e:
        return [{"error": f"Error generating quiz: {e}"}]
