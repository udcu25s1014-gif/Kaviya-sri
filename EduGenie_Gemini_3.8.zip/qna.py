"""
qna.py
General question-answering, powered by Gemini.
"""

from config import client, GEMINI_MODEL


def answer_question_with_gemini(question: str) -> str:
    """Send a free-form question to Gemini and return a plain-text answer."""
    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=question,
        )
        return response.text.strip()
    except Exception as e:
        return f"⚠️ Error in QnA: {e}"
