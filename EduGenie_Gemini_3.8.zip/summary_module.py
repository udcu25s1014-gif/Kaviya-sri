"""
summary_module.py
Summarizes long passages into short, easy-to-understand versions.
"""

from config import client, GEMINI_MODEL


def summarize_text(text: str) -> str:
    prompt = f"Summarize the following text in simple language:\n\n{text}"
    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
        )
        return response.text.strip()
    except Exception as e:
        return f"⚠️ Error in Summary: {e}"
