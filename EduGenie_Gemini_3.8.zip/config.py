"""
config.py
Loads environment variables and creates a single shared Gemini client
that every module in the app reuses.
"""

import os
from dotenv import load_dotenv
from google import genai

# Load variables from a local .env file (see .env.example)
load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")

if not GEMINI_API_KEY:
    raise RuntimeError(
        "GEMINI_API_KEY is not set.\n"
        "1. Copy .env.example to .env\n"
        "2. Paste your Google Gemini API key into it\n"
        "3. Restart the server"
    )

# One client, reused everywhere (qna.py, explanation_module.py, etc.)
client = genai.Client(api_key=GEMINI_API_KEY)
